"use client"

import HockeyStatsPage from "../hockey-stats-page"

export default function SyntheticV0PageForDeployment() {
  return <HockeyStatsPage />
}